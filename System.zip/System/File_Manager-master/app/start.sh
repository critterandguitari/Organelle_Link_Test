cherryd -i cpapp -c prod.conf

